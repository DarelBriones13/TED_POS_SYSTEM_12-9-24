const express = require("express");
const path = require("path");
const { login } = require("../controllers/authController");
const { saveCategory, getCategories } = require("../controllers/categoryController");
const { addSupplier, getSuppliers, updateSupplier, getSupplierById } = require("../controllers/supplierController");
const { addInventoryAndProduct } = require('../controllers/inventoryController');
const multer = require('multer');
const { User } = require('../models');
const { getProducts } = require('../controllers/bundleController');
const { saveBundle } = require('../controllers/bundleController');
const { processOrder, getOrders, getOrderDetails, updateOrder, getEditOrderDetails } = require('../controllers/orderController');
const { getDashboardData, getDailySalesData } = require('../controllers/dashboardController');
const { getSalesReport } = require('../controllers/salesreportController');
const db = require("../models");

const routes = express.Router();

// -------------------- AUTHENTICATION MIDDLEWARE --------------------
// Middleware to check if the user is authenticated
const isAuthenticated = (req, res, next) => {
  if (!req.session.userId) {
    return res.redirect('/login'); // Redirect to login page if not authenticated
  }
  next(); // Proceed to the next middleware or route handler
};

// -------------------- AUTHENTICATION ROUTES --------------------
// Login route
routes.get("/login", (req, res) => {
  res.render("index"); // No need for file extension if you're using EJS
});

routes.post("/login", login); // Login form submission

// -------------------- LOGOUT ROUTE --------------------
routes.get("/logout", (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Error destroying session:', err);
      return res.status(500).send('Internal server error');
    }
    res.redirect("/login"); // Redirect to login page after logout
  });
});

// -------------------- DASHBOARD AND PAGE ROUTES --------------------
// Serve dashboard.ejs after successful login
routes.get("/dashboard", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("dashboard", { activePage: 'dashboard', userType }); // Pass userType to the view
});

routes.get("/orders", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("orders", { activePage: 'orders', userType }); // Pass userType to the view
});

routes.get("/editorders", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("editorders", { activePage: 'editorders', userType }); // Pass userType to the view
});

routes.get("/takeorders", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("takeorders", { activePage: 'takeorders', userType }); // Pass userType to the view
});

routes.get("/inventory", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("inventory", { activePage: 'inventory', userType }); // Pass userType to the view
});

routes.get("/supplier", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("supplier", { activePage: 'supplier', userType }); // Pass userType to the view
});

routes.get("/products", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("products", { activePage: 'products', userType }); // Pass userType to the view
});

routes.get("/bundleslist", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("bundleslist", { activePage: 'bundleslist', userType }); // Pass userType to the view
});

routes.get("/addbundle", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("addbundle", { activePage: 'addbundle', userType }); // Pass userType to the view
});

routes.get("/editBundle", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("editBundle", { activePage: 'editBundle', userType }); // Pass userType to the view
});

routes.get("/salereport", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("salereport", { activePage: 'salereport', userType }); // Pass userType to the view
});

// -------------------- CATEGORY ROUTES --------------------
// Get all categories and serve categories.ejs
routes.get("/categories", isAuthenticated, async (req, res) => {
  try {
    const categories = await getCategories();
    const userType = req.session.userType; // Get userType from session
    res.render("categories", { categories, activePage: 'categories', userType }); // Pass userType to the view
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).send('Internal server error');
  }
});

// Fetch categories list as JSON
routes.get("/categories/list", isAuthenticated, async (req, res) => {
  try {
    const categories = await getCategories();
    res.json(categories); // Return categories as JSON
  } catch (error) {
    console.error("Error fetching categories:", error);
    res.status(500).send('Internal server error');
  }
});

// Update category by ID
routes.put("/categories/:id", isAuthenticated, async (req, res) => {
  const categoryId = req .params.id;
  const { category_name, category_description } = req.body;

  try {
    const category = await db.Category.findByPk(categoryId);
    if (!category) {
      return res.status(404).json({ message: 'Category not found.' });
    }

    category.category_name = category_name;
    category.category_description = category_description;
    await category.save();

    res.json(category); // Respond with the updated category
  } catch (error) {
    console.error('Error updating category:', error);
    res.status(500).json({ message: 'Internal server error', error: error.message });
  }
});

// Handle form submission for saving categories
routes.post("/categories", isAuthenticated, saveCategory);

// -------------------- USER MANAGEMENT ROUTES --------------------
// Serve user.ejs at the /users route
routes.get("/users", isAuthenticated, (req, res) => {
  const userType = req.session.userType; // Get userType from session
  res.render("user", { activePage: 'users', userType }); // Pass userType to the view
});

// Get all users (for display)
routes.get('/users/list', isAuthenticated, async (req, res) => {
  const users = await User.findAll();
  res.json(users); // Return the users as JSON
});

// Add a new user
routes.post("/users", isAuthenticated, async (req, res) => {
  const { name, username, password, userType } = req.body;
  try {
    const newUser  = await User.create({ name, username, password, userType });
    res.json(newUser );
  } catch (error) {
    res.status(400).json({ error: "Error creating user" });
  }
});

// Get a user by ID
routes.get("/users/:id", isAuthenticated, async (req, res) => {
  const { id } = req.params;
  try {
    const user = await User.findByPk(id);
    if (user) {
      res.json(user);
    } else {
      res.status(404).json({ error: "User  not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "Internal server error" });
  }
});

// Update a user by ID
routes.put("/users/:id", isAuthenticated, async (req, res) => {
  const { id } = req.params;
  const { name, username, password, userType } = req.body;

  try {
    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({ error: "User  not found" });
    }

    user.name = name || user.name;
    user.username = username || user.username;
    user.password = password || user.password;
    user.userType = userType || user.userType;

    await user.save();
    res.json(user); // Return the updated user
  } catch (error) {
    console.error("Error updating user:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// Delete a user by ID
routes.delete("/users/:id", isAuthenticated, async (req, res) => {
  const { id } = req.params;
  try {
    const user = await User.findByPk(id);
    if (user) {
      await user.destroy();
      res.json({ message: "User  deleted" });
    } else {
      res.status(404).json({ error: "User  not found" });
    }
  } catch (error) {
    res.status(500).json({ error: "Error deleting user" });
  }
});

// -------------------- SUPPLIER ROUTES --------------------
// Add a supplier
routes.post("/suppliers", isAuthenticated, addSupplier);

// Get all suppliers
routes.get("/suppliers", isAuthenticated, getSuppliers);

// Get supplier by ID
routes.get("/suppliers/:id", isAuthenticated, getSupplierById);

// Update a supplier
routes.put("/suppliers/:id", isAuthenticated, updateSupplier);

// Route to get all supplier names (only IDs and names)
routes.get('/suppliers/names', isAuthenticated, async (req, res) => {
  try {
    const suppliers = await db.Supplier.findAll({
      attributes: ['supplier_id', 'supplier_name'] // Only fetch supplier_id and supplier_name
    });
    res.json(suppliers); // Send the supplier names as JSON
  } catch (error) {
    console.error("Error fetching supplier names:", error);
    res.status(500).send('Internal server error');
  }
});

// Set up multer storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
      cb(null, 'uploads/'); // Destination folder
  },
  filename: (req, file, cb) => {
      cb(null, Date.now() + path.extname(file.originalname)); // Add timestamp to filename
  }
});
const upload = multer({ storage });

// Add inventory and product
routes.post("/inventory", isAuthenticated, upload.single('productImage'), addInventoryAndProduct);

// Fetch all inventory records
routes.get("/inventories/list", async (req, res) => {
  try {
      const inventories = await db.inventory.findAll({
          include: [
              {
                  model: db.products, // The model to include
                  as: 'product', // Use the alias defined in the association
                  attributes: ['product_name', 'product_model'] // Specify attributes to fetch
              },
              {
                  model: db.Supplier, // The model to include
                  as: 'Supplier', // Use the alias defined in the association
                  attributes: ['supplier_name'] // Specify attributes to fetch
              }
          ]
      });
      res.json(inventories); // Return the inventories as JSON
  } catch (error) {
      console.error("Error fetching inventories:", error);
      res.status(500).send('Internal server error');
  }
});

// Fetch all products with their associated categories
routes.get("/products/list", async (req, res) => {
  try {
      const products = await db.products.findAll({
          include: [
              {
                  model: db.Category, // Include the Category model
                  as: 'category', // Use the alias defined in the association
                  attributes: ['category_name'] // Specify attributes to fetch from the category
              }
          ],
          attributes: ['product_id', 'product_name', 'product_model', 'selling_price', 'product_quantity', 'product_img'] // Include product_img
      });
      res.json(products); // Return products as JSON
  } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).send('Internal server error');
  }
});

// Update inventory and product
routes.put('/inventory/:id', upload.single('productImage'), async (req, res) => {
  const inventoryId = req.params.id;
  const {
    productName,
    productModel,
    stock,
    dateReceived,
    supplierId,
    purchasePrice,
    sellingPrice,
    status
  } = req.body;

  // Basic validation
  if (!productName || !stock || !supplierId || !purchasePrice || !sellingPrice || !status) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const transaction = await db.sequelize.transaction(); // Start a transaction

  try {
    // Find the inventory entry
    const inventory = await db.inventory.findOne({ where: { inventory_id: inventoryId } });
    if (!inventory) {
      return res.status(404).json({ error: 'Inventory not found' });
    }

    // Find the product associated with the inventory
    const product = await db.products.findOne({ where: { product_id: inventory.product_id } });
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    // Update the product fields (excluding product_id)
    product.product_name = productName;
    product.product_model = productModel;
    product.product_quantity = stock; // Update product quantity
    product.selling_price = sellingPrice; // Update selling price
    product.product_status = status; // Update product status

    // Check if a new image file is uploaded
    if (req.file) {
      // If a new image is uploaded, update the product_img field
      product.product_img = req.file.filename; // Save the new filename
    }

    await product.save(); // Save the updated product

    // Update the inventory entry
    inventory.stocks = stock;
    inventory.date_received = dateReceived;
    inventory.supplier_id = supplierId;
    inventory.purchase_price = purchasePrice; // Update purchase price in inventory
    inventory.inventory_status = status; // Update inventory status
    await inventory.save();

    await transaction.commit(); // Commit the transaction
    return res.status(200).json({ message: 'Product and inventory updated successfully' });
  } catch (error) {
    await transaction.rollback(); // Rollback the transaction in case of error
    console.error("Error updating product and inventory:", error); // Log the error
    return res.status(500).json({ error: 'Internal server error', details: error.message });
  }
});

// Get inventory details by ID
routes.get('/inventories/:id', async (req, res) => {
  const inventoryId = req.params.id;
  try {
    const inventory = await db.inventory.findOne({
      where: { inventory_id: inventoryId },
      include: [
        {
          model: db.products,
          as: 'product',
          attributes: ['product_name', 'product_model', 'selling_price'] // Removed purchase_price
        },
        {
          model: db.Supplier,
          as: 'Supplier',
          attributes: ['supplier_name']
        }
      ]
    });

    if (!inventory) {
      return res.status(404).json({ error: 'Inventory not found' });
    }

    console.log("Fetched Inventory:", JSON.stringify(inventory, null, 2)); // Log the inventory details

    // Return the inventory details, including purchase_price from the inventory object
    res.json({
      inventory_id: inventory.inventory_id,
      stocks: inventory.stocks,
      date_received: inventory.date_received,
      supplier_id: inventory.supplier_id,
      product_id: inventory.product_id,
      user_id: inventory.user_id,
      purchase_price: inventory.purchase_price, // Access purchase_price from inventory
      inventory_status: inventory.inventory_status,
      product: inventory.product, // Include product details
      Supplier: inventory.Supplier // Include supplier details
    });
  } catch (error) {
    console.error("Error fetching inventory details:", error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Add this route to fetch products
routes.get("/products/data", isAuthenticated, getProducts);

// -------------------- BUNDLE ROUTE --------------------
// Add this route to save the bundle
routes.post("/bundles", isAuthenticated, upload.single('bundle_image'), saveBundle);

// Fetch all bundles as JSON
routes.get("/bundles/list", isAuthenticated, async (req, res) => {
  try {
    const bundles = await db.Bundles.findAll({
      include: [
        {
          model: db.products,
          as: 'products', // Use the alias defined in the association
          attributes: ['product_name'] // Fetch only the product names
        }
      ],
      attributes: ['bundle_id', 'bundle_name', 'total_price', 'discount', 'bundle_status', 'bundle_description', 'bundle_image']
    });
    res.json(bundles); // Return bundles as JSON  
  } catch (error) {
    console.error("Error fetching bundles:", error); // Log the error for debugging
    res.status(500).json({ error: 'Internal server error', details: error.message }); // Return a JSON response with the error
  }
});

// Add this route for processing orders
routes.post("/orders", isAuthenticated, processOrder);

// Fetch all orders and render orders.ejs
routes.get("/orders", isAuthenticated, async (req, res) => {
  try {
      const orders = await getOrders(); // Call getOrders without passing req and res
      const userType = req.session.userType; // Get userType from session
      res.render("orders", { activePage: 'orders', userType, orders }); // Pass orders to the view
  } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).send('Internal server error');
  }
});

// Fetch orders as JSON
routes.get("/orders/list", isAuthenticated, async (req, res) => {
  try {
      const orders = await getOrders(); // Call getOrders without passing req and res
      res.json(orders); // Return orders as JSON
  } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).send('Internal server error');
  }
});

// Fetch order details by ID
routes.get("/orders/:id", isAuthenticated, getOrderDetails);

routes.put("/orders/:id", isAuthenticated, updateOrder); 

// Fetch order details by ID
routes.get("/orders/edit/:id", isAuthenticated, getEditOrderDetails);


// -------------------- DASHBOARD DATA ROUTE --------------------
// Fetch dashboard data
routes.get("/dashboard/data", isAuthenticated, getDashboardData);

// New daily sales data route
routes.get('/dashboard/daily-sales', isAuthenticated, getDailySalesData);

// -------------------- SALES REPORT DATA ROUTE --------------------
routes.get("/salesreport", isAuthenticated, async (req, res) => {
  try {
    const { start_date, end_date } = req.query;

    // Get the filtered orders if dates are provided
    const orders = await getSalesReport(start_date, end_date);

    // Calculate the grand total by summing up the total_amount of each order
    const grandTotal = orders.reduce((total, order) => total + order.total_amount, 0);

    console.log('Sending Filtered Orders:', orders);  // Log the filtered data
    console.log('Grand Total:', grandTotal);

    // Send the filtered orders and grand total as JSON response
    res.json({ orders, grandTotal });
  } catch (error) {
    console.error("Error fetching sales report:", error);
    res.status(500).send('Internal server error');
  }
});

// -------------------- STATIC FILES AND OTHER ROUTES --------------------
// Serve static files
routes.use(express.static(path.join(__dirname, "public ")));

// Serve static files from the uploads directory
routes.use('/uploads', express.static(path.join(__dirname, '../uploads')));

module.exports = routes;