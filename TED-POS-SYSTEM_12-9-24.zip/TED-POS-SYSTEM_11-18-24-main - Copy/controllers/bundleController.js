// controllers/bundleController.js
const db = require('../models');

exports.getProducts = async (req, res) => {
  try {
    const products = await db.products.findAll();
    res.json(products); // Return products as JSON
  } catch (error) {
    console.error("Error fetching products:", error);
    res.status(500).send('Internal server error');
  }
};

exports.saveBundle = async (req, res) => {
  const { bundle_name, discount, bundle_description, product_ids, total_price, bundle_status } = req.body;

  console.log("Received data:", req.body); // Log the received data

  // Validate required fields
  if (!bundle_name || !total_price || !product_ids) {
      return res.status(400).json({ error: 'Missing required fields' });
  }

  try {
      // Create a new bundle entry
      const newBundle = await db.Bundles.create({
          bundle_name,
          bundle_image: req.file ? req.file.filename : null, // Save the uploaded file name
          bundle_description,
          total_price,
          discount: discount || 0, // Default discount to 0 if not provided
          bundle_status: bundle_status ? 'Available' : 'Unavailable', // Set status based on input
          product_ids: JSON.parse(product_ids) // Ensure this is parsed correctly
      });

      // Parse product_ids and associate products with the bundle
      const productIds = JSON.parse(product_ids);
      await newBundle.addProducts(productIds); // Use the association method to add products

      // Respond with success message
      res.status(201).json({ message: 'Bundle Successfully Added', bundle: newBundle });
  } catch (error) {
      console.error("Error saving bundle:", error); // Log the error
      res.status(500).json({ error: 'Internal server error' });
  }
};

