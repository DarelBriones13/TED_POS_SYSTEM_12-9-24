const { Order, OrderItem, User, products, Bundles, inventory: Inventory } = require('../models');

const processOrder = async (req, res) => {
    try {
        const { selectedProducts, selectedBundles, amountRendered, price, totalQuantity, orderDetails } = req.body;
        const userId = req.session.userId;

        // Validation checks
        if ((!selectedProducts || selectedProducts.length === 0) && 
            (!selectedBundles || selectedBundles.length === 0)) {
            return res.status(400).json({ error: "No products or bundles selected for the order." });
        }

        if (!amountRendered || amountRendered < 0) {
            return res.status(400).json({ error: "Invalid amount rendered." });
        }

        const changeAmount = amountRendered - price;

        const order = await Order.create({
            ref_num: generateReferenceNumber(),
            or_num: generateOrderNumber(),
            total_amount: price,
            amount_rendered: amountRendered,
            change_amount: changeAmount > 0 ? changeAmount : 0,
            total_items: totalQuantity,
            date_created: new Date(),
            user_id: userId,
        });

        const cashier = await User.findOne({ where: { id: userId } });

        // Process selected products
        for (const productId of selectedProducts) {
            const productRow = orderDetails.find(item => item.product_id === productId);
            if (productRow) {
                await OrderItem.create({
                    orders_id: order.orders_id,
                    product_id: productId,
                    bundle_id: null,
                    quantity: productRow.quantity,
                    price: productRow.price,
                    amount: productRow.price * productRow.quantity,
                });

                const product = await products.findByPk(productId);
                if (product) {
                    if (product.product_quantity >= productRow.quantity) {
                        product.product_quantity -= productRow.quantity; // Decrement product quantity
                        await product.save();
                    } else {
                        return res.status(400).json({ error: `Not enough stock for ${product.product_name}.` });
                    }
                }

                // Update inventory stocks
                const inventoryRecord = await Inventory.findOne({ where: { product_id: productId } });
                if (inventoryRecord) {
                    if (inventoryRecord.stocks >= productRow.quantity) {
                        inventoryRecord.stocks -= productRow.quantity; // Decrement inventory stocks
                        await inventoryRecord.save();
                    } else {
                        return res.status(400).json({ error: `Not enough inventory for ${product.product_name}.` });
                    }
                }
            }
        }

        // Process selected bundles
        for (const bundleId of selectedBundles) {
            const bundleRow = orderDetails.find(item => item.bundle_id === bundleId);
            if (bundleRow) {
                await OrderItem.create({
                    orders_id: order.orders_id,
                    product_id: null,
                    bundle_id: bundleId,
                    quantity: bundleRow.quantity,
                    price: bundleRow.price,
                    amount: bundleRow.price * bundleRow.quantity,
                });

                const bundle = await Bundles.findOne({
                    where: { bundle_id: bundleId },
                    include: {
                        model: products,
                        as: 'products',
                        attributes: ['product_id', 'product_name'], // Include product name for error messages
                    },
                });

                if (bundle) {
                    // Deduct stock for each product in the bundle
                    for (const includedProduct of bundle.products) {
                        const product = await products.findByPk(includedProduct.product_id);
                        if (product) {
                            const quantityToDeduct = bundleRow.quantity; // Only reduce by the number of bundles purchased
                            if (product.product_quantity >= quantityToDeduct) {
                                product.product_quantity -= quantityToDeduct; // Decrement product quantity by 1 for each bundle
                                await product.save();
                            } else {
                                return res.status(400).json({ error: `Not enough stock for ${product.product_name}.` });
                            }

                            // Update inventory stocks for included products
                            const inventoryRecord = await Inventory.findOne({ where: { product_id: product.product_id } });
                            if (inventoryRecord) {
                                if (inventoryRecord.stocks >= quantityToDeduct) {
                                    inventoryRecord.stocks -= quantityToDeduct; // Decrement inventory stocks by 1 for each bundle
                                    await inventoryRecord.save();
                                } else {
                                    return res.status(400).json({ error: `Not enough inventory for ${product.product_name}.` });
                                }
                            }
                        }
                    }
                }
            }
        }
        return res.status(201).json({
            message: "Order processed successfully.",
            order,
            cashierName: cashier.name, // Include cashier's name
            dateCreated: order.date_created, // Include date created
            refNum: order.ref_num, // Include reference number
            orNum: order.or_num // Include order number
        });
    } catch (error) {
        console.error("Error processing order:", error);
        return res.status(500).json({ error: "An error occurred while processing the order." });
    }
};

// Function to generate random reference number
const generateReferenceNumber = () => {
    return "INV-" + Math.random().toString(36).substr(2, 9).toUpperCase();
};

// Function to generate random order number
const generateOrderNumber = () => {
    return "OR-" + Math.random().toString(36).substr(2, 9).toUpperCase();
};

const getOrders = async () => {
    try {
        const orders = await Order.findAll({
            attributes: ['orders_id', 'date_created', 'ref_num', 'total_items', 'total_amount'],
            include: [{
                model: User,
                attributes: ['name'] // Include user name if needed
            }]
        });
        return orders; // Return the fetched orders
    } catch (error) {
        console.error("Error fetching orders:", error);
        throw error; // Rethrow the error for handling in the route
    }
};

const getEditOrderDetails = async (req, res) => {
    const { id } = req.params; // Get order ID from request params
    try {
        // Fetch order by ID and include OrderItems with product and bundle details
        const order = await Order.findOne({
            where: { orders_id: id },
            include: [
                {
                    model: OrderItem,
                    attributes: ['quantity', 'price', 'product_id', 'bundle_id'],
                    include: [
                        {
                            model: products, // Use products instead of Product
                            attributes: ['product_name'], // Include product name
                            as: 'Product' // Ensure this matches the alias in the association
                        },
                        {
                            model: Bundles,
                            attributes: ['bundle_name'], // Include bundle name
                            as: 'Bundle' // Ensure this matches the alias in the association
                        }
                    ]
                },
                {
                    model: User,
                    attributes: ['name'], // Include cashier's name
                }
            ]
        });

        if (!order) {
            return res.status(404).json({ error: "Order not found." });
        }

        // Return order and order items
        res.json(order);
    } catch (error) {
        console.error("Error fetching order details:", error);
        res.status(500).json({ error: "Internal server error." });
    }
};

const getOrderDetails = async (req, res) => {
    const { id } = req.params; // Get order ID from request params

    try {
        // Fetch order by ID and include OrderItems with product and bundle details
        const order = await Order.findOne({
            where: { orders_id: id },
            include: [
                {
                    model: OrderItem,
                    attributes: ['quantity', 'amount', 'product_id', 'bundle_id'],
                    include: [
                        {
                            model: products, // Use products instead of Product
                            attributes: ['product_name'], // Include product name
                            as: 'Product' // Ensure this matches the alias in the association
                        },
                        {
                            model: Bundles,
                            attributes: ['bundle_name'], // Include bundle name
                            as: 'Bundle' // Ensure this matches the alias in the association
                        }
                    ]
                },
                {
                    model: User,
                    attributes: ['name'], // Include cashier's name
                }
            ]
        });

        if (!order) {
            return res.status(404).json({ error: "Order not found." });
        }

        // Return order and order items
        res.json(order);
    } catch (error) {
        console.error("Error fetching order details:", error);
        res.status(500).json({ error: "Internal server error." });
    }
};


const updateOrder = async (req, res) => {
    const { id } = req.params;
    const { selectedProducts, selectedBundles, amountRendered, price, totalQuantity, orderDetails } = req.body;

    try {
        // Find the existing order
        const order = await Order.findByPk(id);
        if (!order) {
            return res.status(404).json({ error: "Order not found." });
        }

        // Update order fields
        order.total_amount = price;
        order.amount_rendered = amountRendered;
        order.change_amount = amountRendered - price;
        order.total_items = totalQuantity;
        order.date_created = new Date(); // Update date_created to current date
        await order.save();

        // Fetch existing order items
        const existingOrderItems = await OrderItem.findAll({ where: { orders_id: id } });

        // Create a map for existing order items for easy lookup
        const existingOrderItemsMap = {};
        existingOrderItems.forEach(item => {
            existingOrderItemsMap[item.product_id || item.bundle_id] = item; // Use product_id or bundle_id as key
        });

        // Update existing order items and track new items
        const newOrderItems = [];
        for (const detail of orderDetails) {
            const { product_id, bundle_id, quantity, price } = detail;

            if (product_id || bundle_id) {
                const existingItem = existingOrderItemsMap[product_id || bundle_id];

                if (existingItem) {
                    // Update existing item
                    existingItem.quantity = quantity;
                    existingItem.price = price;
                    existingItem.amount = price * quantity; // Recalculate amount
                    await existingItem.save();
                } else {
                    // Create new order item
                    const newItem = await OrderItem.create({
                        orders_id: id,
                        product_id: product_id || null,
                        bundle_id: bundle_id || null,
                        quantity,
                        price,
                        amount: price * quantity,
                    });
                    newOrderItems.push(newItem);
                }
            }
        }

        // Return response
        return res.status(200).json({ message: "Order updated successfully.", newOrderItems });
    } catch (error) {
        console.error("Error updating order:", error);
        return res.status(500).json({ error: "Internal server error." });
    }
};

module.exports = {
    processOrder, getOrders, getOrderDetails, updateOrder, getEditOrderDetails
};