let originalProducts = []; // Store the original products for filtering

document.addEventListener('DOMContentLoaded', function() {
    // Fetch products ```javascript
    async function fetchProducts() {
        const response = await fetch('/products/data');
        originalProducts = await response.json(); // Store the original products
        displayProducts(originalProducts); // Initially display all products
    }

    // Fetch categories and populate the category dropdown
    async function fetchCategories() {
        const response = await fetch('/categories/list');
        const categories = await response.json();
        const categorySelect = document.getElementById('category-select');

        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.category_id; // Assuming category_id is the identifier
            option.textContent = category.category_name;
            categorySelect.appendChild(option);
        });

        // Initialize Select2 on the category select element
        $(categorySelect).select2({
            placeholder: "Select a category",
            allowClear: true
        });
    }

    // Function to display products based on the filtered list
    window.displayProducts = function(products) {
        const productGrid = document.getElementById('product-grid');
        productGrid.innerHTML = ''; // Clear existing products

        products.forEach(product => {
            const productPlaceholder = document.createElement('div');
            productPlaceholder.className = 'product-placeholder';
            productPlaceholder.innerHTML = `
                <img src="/uploads/${product.product_img || 'default-image.jpg'}" alt="${product.product_name}" />
                <p>${product.product_name}</p>
                <p class="Model">${product.product_model}</p>
                <span class="price-tag">₱${product.selling_price}</span>
            `;
            // Add click event to the productPlaceholder
            productPlaceholder.addEventListener('click', function() {
                const productPrice = parseFloat(product.selling_price);
                if (!isNaN(productPrice)) {
                    addToBundleList(product.product_name, productPrice, product.product_id); // Pass product_id
                } else {
                    console.error('Product price is not a valid number:', product.selling_price);
                }
            });
            productGrid.appendChild(productPlaceholder);
        });
    };

    // Function to add product to the bundle list
    function addToBundleList(productName, productPrice, productId) {
        const bundleListBody = document.getElementById('bundle-list-body');
        const existingRow = Array.from(bundleListBody.querySelectorAll('tr')).find(row => {
            const nameCell = row.querySelector('td:nth-child(2)');
            return nameCell.textContent === productName;
        });

        if (existingRow) {
            // If the product already exists, increment the quantity
            const quantityInput = existingRow.querySelector('.quantity-input');
            quantityInput.value = parseInt(quantityInput.value) + 1; // Increase quantity by 1
        } else {
            // If the product does not exist, create a new row
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>
                    <div class="quantity-control">
                        <button class="quantity-btn decrement-btn" onclick="decrementQuantity(this)">
                            <i class="bx bx-minus"></i>
                        </button>
                        <input type="number" value="1" min="1" class="quantity-input" />
                        <button class="quantity-btn increment-btn" onclick="incrementQuantity(this)">
                            <i class="bx bx-plus"></i>
                        </button>
                    </div>
                </td>
                <td>${productName}</td>
                <td>₱${productPrice.toFixed(2)}</td>
                <td>
                    <button class="delete-btn" onclick="deleteRow(this)">
                        <i class="bx bx-trash"></i>
                    </button>
                </td>
            `;
            newRow.setAttribute('data-product-id', productId); // Set product ID as a data attribute
            bundleListBody.appendChild(newRow);
        }

        // Update total price and product IDs
        updateTotalPrice();
        updateProductIds();
    }

    // Function to delete a row from the bundle list
    window.deleteRow = function(button) {
        const row = button.closest('tr');
        row.remove();
        updateTotalPrice();
        updateProductIds(); // Update product IDs after deletion
    };

    // Function to decrement quantity
    window.decrementQuantity = function(button) {
        const input = button.nextElementSibling;
        let value = parseInt(input.value);
        if (value > 1) {
            input.value = value - 1;
            updateTotalPrice();
            updateProductIds(); // Update product IDs after decrement
        }
    };

    // Function to increment quantity
    window.incrementQuantity = function(button) {
        const input = button.previousElementSibling;
        let value = parseInt(input.value);
        input.value = value + 1;
        updateTotalPrice();
        updateProductIds(); // Update product IDs after increment
    };

    // Function to update total price
    function updateTotalPrice() {
        const rows = document.querySelectorAll('#bundle-list-body tr');
        let total = 0;

        rows.forEach(row => {
            const priceCell = row.querySelector('td:nth-child(3)');
            const price = parseFloat(priceCell.textContent.replace('₱', '').replace(',', ''));
            const quantityInput = row.querySelector('.quantity-input');
            const quantity = parseInt(quantityInput.value);
            total += price * quantity;
        });

        // Get the discount value
        const discountInput = document.querySelector('input[name="discount"]');
        const discountPercentage = parseFloat(discountInput.value) || 0; // Default to 0 if not a number

        // Calculate the discount amount
        const discountAmount = (total * discountPercentage) / 100;
        const discountedTotal = total - discountAmount;

        document.getElementById('total-price').textContent = `₱${discountedTotal.toFixed(2)}`;
        document.getElementById('total_price_input').value = discountedTotal.toFixed(2); // Update hidden total price input
    }

    // Function to update product IDs based on the current bundle list
    function updateProductIds() {
        const productIds = [];
        const rows = document.querySelectorAll('#bundle-list-body tr');

        rows.forEach(row => {
            const productId = row.getAttribute('data-product-id'); // Get product ID from data attribute
            if (productId) {
                productIds.push(productId);
            }
        });

        document.getElementById('product_ids').value = JSON.stringify(productIds); // Store as JSON string
    }

    // Initialize the product fetching and category fetching
    fetchProducts();
    fetchCategories(); // Fetch categories on load

    // Search functionality for products
    document.getElementById('product-search').addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        filterProducts(searchTerm);
    });

    // Category filter functionality with Select2
    $('#category-select').on('change', function() {
        const selectedCategory = $(this).val();
        const searchTerm = document.getElementById('product-search').value.toLowerCase();
        filterProducts(searchTerm, selectedCategory);
    });

    // Function to filter products based on search term and selected category
    function filterProducts(searchTerm, selectedCategory = 'all') {
        let filteredProducts = originalProducts;

        // Filter by search term
        if (searchTerm) {
            filteredProducts = filteredProducts.filter(product =>
                product.product_name.toLowerCase().includes(searchTerm) ||
                product.product_model.toLowerCase().includes(searchTerm)
            );
        }

        // Filter by selected category
        if (selectedCategory && selectedCategory !== 'all') {
            filteredProducts = filteredProducts.filter(product => product.category_id == selectedCategory); // Assuming category_id is available
        }

        displayProducts(filteredProducts); // Display the filtered products
    }

    // Save function (to be implemented later)
    window.saveBundle = function() {
        // Logic for saving the edited bundle will be added here
        alert('Save functionality to be implemented.');
    };

    // Fetch products and categories on load
    fetchProducts();
    fetchCategories();
});

// Function to update the bundle
window.updateBundle = async function(bundleId) {
    const formData = new FormData();
    const bundleName = document.querySelector('input[name="bundle_name"]').value;
    const discount = document.querySelector('input[name="disco  unt"]').value;
    const bundleDescription = document.querySelector('textarea[name="bundle_description"]').value;
    const bundleStatus = document.querySelector('input[name="bundle_status"]').checked;
    const productIds = document.getElementById('product_ids').value;
    const totalPrice = document.getElementById('total_price_input').value;

    // Append data to FormData
    formData.append('bundle_name', bundleName);
    formData.append('discount', discount);
    formData.append('bundle_description', bundleDescription);
    formData.append('bundle_status', bundleStatus);
    formData.append('product_ids', productIds);
    formData.append('total_price', totalPrice);

    try {
        const response = await fetch(`/bundles/${bundleId}`, {
            method: 'PUT',
            body: formData
        });

        if (response.ok) {
            const result = await response.json();
            alert(result.message); // Show success message
            window.location.href = '/bundleslist'; // Redirect to bundles list
        } else {
            const error = await response.json();
            alert(error.error || 'An error occurred while updating the bundle.');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('An error occurred while updating the bundle.');
    }
};