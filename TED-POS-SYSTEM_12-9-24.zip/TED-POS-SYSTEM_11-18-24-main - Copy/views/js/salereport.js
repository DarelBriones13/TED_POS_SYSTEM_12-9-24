document.addEventListener('DOMContentLoaded', function () {
  // Define the populateTable function to populate the sales report table
  function populateTable(orders, grandTotal) {
    const orderTableBody = document.getElementById('order-table-body');
    const totalRow = document.getElementById('total-row');
    const grandTotalCell = document.getElementById('grand-total');

    // Clear the existing table body
    orderTableBody.innerHTML = '';

    // Populate the table with new data
    orders.forEach(order => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${new Date(order.date_created).toLocaleDateString()}</td>
        <td>${order.ref_num}</td>
        <td>${order.or_num}</td>
        <td>${order.total_items || 0}</td> <!-- Default to 0 -->
        <td>₱${(order.total_amount || 0).toFixed(2)}</td> <!-- Default to 0.00 -->
      `;
      orderTableBody.appendChild(row);
    });

    // Update the grand total
    grandTotalCell.textContent = `₱${grandTotal.toFixed(2)}`;

    // Show or hide the total row based on whether there are orders
    totalRow.style.display = orders.length > 0 ? '' : 'none';
  }

  // Initial data fetch when the page loads
  fetch('/salesreport')
    .then(response => response.json())
    .then(data => {
      console.log('Initial Data:', data); // Log the initial data
      populateTable(data.orders, data.grandTotal);
    })
    .catch(error => {
      console.error('Error fetching sales report:', error);
    });

  // Handle the filter form submit
  document.getElementById('apply-filter').addEventListener('click', function () {
    const startDate = document.getElementById('start-date').value;
    const endDate = document.getElementById('end-date').value;

    // Validate the dates
    if (startDate && endDate) {
      const params = new URLSearchParams({
        start_date: startDate, // Send start date in YYYY-MM-DD format
        end_date: endDate      // Send end date in YYYY-MM-DD format
      });

      fetch(`/salesreport?${params.toString()}`)
        .then(response => response.json())
        .then(data => {
          console.log('Filtered Data:', data); // Log the filtered data
          populateTable(data.orders, data.grandTotal);
        })
        .catch(error => {
          console.error('Error fetching filtered sales report:', error);
        });
    } else {
      alert('Please select both start and end dates');
    }
  });

  // Handle the reset filter button click
  document.getElementById('reset-filter').addEventListener('click', function () {
    // Clear filter inputs
    document.getElementById('start-date').value = '';
    document.getElementById('end-date').value = '';

    // Fetch and populate the table with all data
    fetch('/salesreport')
      .then(response => response.json())
      .then(data => {
        console.log('Reset Data:', data); // Log the reset data
        populateTable(data.orders, data.grandTotal); // Repopulate the table with all data
      })
      .catch(error => {
        console.error('Error fetching sales report:', error);
      });
  });
});



document.querySelector('.print-button').addEventListener('click', function () {
  const table = document.querySelector('.report-table'); // Replace with the class or ID of your table
  if (!table) {
    alert('No data to print.');
    return;
  }

  // Create a new window for printing
  const printWindow = window.open('', '_blank');
  printWindow.document.write(`
    <html>
      <head>
        <title>Sales Report</title>
        <style>
          /* Add your table styles here for print */
          table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
          }
          th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
          }
          th {
            background-color: #f2f2f2;
          }
        </style>
      </head>
      <body>
        <h2 style="text-align: center;">Sales Report</h2>
        ${table.outerHTML} <!-- Insert the table HTML -->
      </body>
    </html>
  `);

  // Trigger the print
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
  printWindow.close();
});

document.querySelector('.export-button').addEventListener('click', function () {
  const table = document.querySelector('.report-table'); // Replace with your table class or ID
  if (!table) {
    alert('No data available to export.');
    return;
  }

  let csvContent = '';
  const rows = table.querySelectorAll('tr');

  // Process each row of the table
  rows.forEach((row) => {
    const cells = row.querySelectorAll('th, td');
    const rowData = [];

    cells.forEach((cell) => {
      let cellText = cell.innerText.replace(/"/g, '""'); // Escape quotes
      rowData.push(`"${cellText}"`); // Wrap data in quotes for Excel compatibility
    });

    csvContent += rowData.join(',') + '\n'; // Add a newline for each row
  });

  // Fix encoding for special characters like ₱
  const csvBlob = new Blob([`\ufeff${csvContent}`], { type: 'text/csv;charset=utf-8;' }); // Add BOM for UTF-8
  const csvUrl = URL.createObjectURL(csvBlob);

  // Trigger download
  const tempLink = document.createElement('a');
  tempLink.href = csvUrl;
  tempLink.setAttribute('download', 'SalesReport.csv');
  tempLink.style.display = 'none';
  document.body.appendChild(tempLink);
  tempLink.click();
  document.body.removeChild(tempLink);

  alert('Data exported successfully to SalesReport.csv');
});
