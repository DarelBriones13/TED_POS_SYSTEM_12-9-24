let originalProducts = []; // Store the original products for filtering
let originalBundles = []; // Store the original bundles for filtering
let totalOrderAmount = 0; // Keep track of the total order amount

document.addEventListener('DOMContentLoaded', function () {
    fetchProducts(); // Fetch products on load
    fetchBundles(); // Fetch bundles on load
    fetchCategories(); // Fetch categories on load

    async function fetchProducts() {
        const response = await fetch('/products/data');
        originalProducts = await response.json(); // Store products
        displayProducts(originalProducts); // Initially display all products
    }    

    async function fetchBundles() {
        const response = await fetch('/bundles/list'); // Update this URL to match your endpoint
        originalBundles = await response.json(); // Store the original bundles
        displayBundles(originalBundles); // Initially display all bundles
    }

    async function fetchCategories() {
        const response = await fetch('/categories/list');
        const categories = await response.json();
        const categorySelect = document.getElementById('category-select');
    
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.category_id;
            option.textContent = category.category_name;
            categorySelect.appendChild(option);
        });
    
        // Initialize Select2 for the dropdown
        $(categorySelect).select2({
            placeholder: "Select a category",
            allowClear: true
        });
    }

    function displayProducts(products) {
        const productGrid = document.getElementById('product-grid');
        productGrid.innerHTML = ''; // Clear existing products

        products.forEach(product => {
            const productPlaceholder = document.createElement('div');
            productPlaceholder.className = 'product-placeholder';
            productPlaceholder.innerHTML = `
                <img src="/uploads/${product.product_img || 'default-image.jpg'}" alt="${product.product_name}" />
                <p>${product.product_name}</p>
                <p class="Model">${product.product_model}</p>
                <p class="available-quantity">Available: ${product.product_quantity}</p>
                <span class="price-tag">₱${product.selling_price}</span>
            `;
            productPlaceholder.addEventListener('click', function () {
                addToOrderList(product.product_name, product.selling_price, product.product_id, false);
            });
            productGrid.appendChild(productPlaceholder);
        });
    }

    function displayBundles(bundles) {
        const productGrid = document.getElementById('product-grid');
        bundles.forEach(bundle => {
            const bundlePlaceholder = document.createElement('div');
            bundlePlaceholder.className = 'product-placeholder';
            bundlePlaceholder.innerHTML = `
                <img src="/uploads/${bundle.bundle_image || 'default-image.jpg'}" alt="${bundle.bundle_name}" />
                <p>${bundle.bundle_name}</p>
                <span class="price-tag">₱${bundle.total_price}</span>
                <span class="show-included" 
                    onmouseenter="showIncludedProducts(event, ${bundle.bundle_id})" 
                    onmouseleave="hideIncludedProducts()">
                    Show Included Products
                </span>
            `;
            bundlePlaceholder.addEventListener('click', function () {
                addToOrderList(bundle.bundle_name, bundle.total_price, bundle.bundle_id, true);
            });
            productGrid.appendChild(bundlePlaceholder);
        });
    }

    function addToOrderList(itemName, itemPrice, itemId, isBundle = false) {
        const orderListBody = document.getElementById('order-list-body');
        const existingRow = Array.from(orderListBody.querySelectorAll('tr')).find(row => {
            const nameCell = row.querySelector('td:nth-child(2)');
            return nameCell.textContent === itemName;
        });
        
        const priceAsNumber = parseFloat(itemPrice);
        
        if (existingRow) {
            const quantityInput = existingRow.querySelector('.quantity-input');
            quantityInput.value = parseInt(quantityInput.value) + 1;
        } else {
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>
                    <div class="quantity-control">
                        <button class="quantity-btn decrement-btn" onclick="decrementQuantity(this)">
                            <i class="bx bx-minus"></i>
                        </button>
                        <input type="number" value="1" min="1" class="quantity-input" />
                        <button class="quantity-btn increment-btn" onclick="incrementQuantity(this)">
                            <i class="bx bx-plus"></i>
                        </button>
                    </div>
                </td>
                <td>${itemName}</td>
                <td> ₱${priceAsNumber.toFixed(2)}</td>
                <td>
                    <button class="delete-btn" onclick="deleteRow(this)">
                        <i class="bx bx-trash"></i>
                    </button>
                </td>
            `;
            // Add a prefix to indicate if it's a product or bundle
            newRow.setAttribute('data-product-id', isBundle ? `bundle-${itemId}` : `product-${itemId}`);
            orderListBody.appendChild(newRow);
        }
        
        updateTotalPrice();
    }

    // Attach `updateTotalPrice` and `updateChange` calls to relevant events
    document.getElementById('amount-tendered').addEventListener('input', updateChange);

    window.deleteRow = function (button) {
        const row = button.closest('tr');
        row.remove();
        updateTotalPrice();
    };

    window.decrementQuantity = function (button) {
        const input = button.nextElementSibling;
        let value = parseInt(input.value);
        if (value > 1) {
            input.value = value - 1;
            updateTotalPrice();
        }
    };

    window.incrementQuantity = function (button) {
        const input = button.previousElementSibling;
        let value = parseInt(input.value);
        input.value = value + 1;
        updateTotalPrice();
    };

    function updateTotalPrice() {
        const rows = document.querySelectorAll('#order-list-body tr');
        let total = 0;

        rows.forEach(row => {
            const priceCell = row.querySelector('td:nth-child(3)');
            const price = parseFloat(priceCell.textContent.replace('₱', '').replace(',', ''));
            const quantityInput = row.querySelector('.quantity-input');
            const quantity = parseInt(quantityInput.value);
            total += price * quantity;
        });

        // Update the total price field
        document.getElementById('total-price').textContent = `₱${total.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;

        // Update the change calculation dynamically
        updateChange();
    }

    // Function to update the change dynamically
    function updateChange() {
        const totalPriceText = document.getElementById('total-price').textContent.replace('₱', '').replace(',', '');
        const totalPrice = parseFloat(totalPriceText) || 0;

        const amountTenderedInput = parseFloat(document.getElementById('amount-tendered').value) || 0;
        const changeField = document.getElementById('change');

        if (amountTenderedInput < totalPrice) {
            changeField.value = 'Insufficient amount';
        } else {
            const change = amountTenderedInput - totalPrice;
            changeField.value = `₱${change.toLocaleString(undefined, { minimumFractionDigits: 2 })}`;
        }
    }

    document.getElementById('product-search').addEventListener('input', function () {
        const searchTerm = this.value.toLowerCase();
        filterProducts(searchTerm);
    });

    $('#category-select').on('change', function() {
        const selectedCategory = $(this).val();
        const searchTerm = document.getElementById('product-search').value.toLowerCase();
        filterProducts(searchTerm, selectedCategory);
    });

    function filterProducts(searchTerm, selectedCategory = 'all') {
        let filteredProducts = originalProducts;  // Assuming originalProducts is a list of all products

        // Apply search term filter
        if (searchTerm) {
            filteredProducts = filteredProducts.filter(product =>
                product.product_name.toLowerCase().includes(searchTerm) ||
                product.product_model.toLowerCase().includes(searchTerm)
            );
        }

        // Apply category filter
        if (selectedCategory && selectedCategory !== 'all') {
            filteredProducts = filteredProducts.filter(product => product.category_id == selectedCategory);
        }

        // Clear the product grid first
        document.getElementById('product-grid').innerHTML = '';

        // Display filtered products
        displayProducts(filteredProducts);  // Make sure this function correctly displays the filtered products

        // Handle bundles (only show them when 'all' is selected)
        if (selectedCategory === 'all') {
            displayBundles(originalBundles);  // Assuming displayBundles is a function to show bundles
        } else {
            // Hide bundles if a specific category is selected
            document.getElementById('bundle-grid').innerHTML = '';  // Clear the bundle grid
        }
    }

    window.showIncludedProducts = function (event, bundleId) {
        const bundle = originalBundles.find(b => b.bundle_id === bundleId);
        if (!bundle || !bundle.products) return;

        const modal = document.getElementById('included-products-modal');
        const productList = document.getElementById('included-products-list');

        // Clear previous modal content
        productList.innerHTML = '';

        // Populate the modal with bundle products
        bundle.products.forEach(product => {
            const li = document.createElement('li');
            li.textContent = product.product_name;
            productList.appendChild(li);
        });

        // Get bounding rectangle of the hovered element
        const rect = event.target.closest('.product-placeholder').getBoundingClientRect();

        // Adjust position to center horizontally and place above the bundle image
        modal.style.top = `${rect.top - modal.offsetHeight}px`; // Place above the bundle
        modal.style.left = `${rect.left + rect.width / 2 - modal.offsetWidth / 2}px`; // Center horizontally
        modal.style.display = 'block'; // Make the modal visible
    };

    let hideTimeout; // Variable to track the hide timeout

    window.hideIncludedProducts = function () {
        // Add a slight delay before hiding the modal
        hideTimeout = setTimeout(() => {
            const modal = document.getElementById('included-products-modal');
            modal.style.display = 'none';
        }, 200); // 200ms delay to prevent flickering
    };

    // Cancel the hiding timeout when re-entering the modal
    document.getElementById('included-products-modal').addEventListener('mouseenter', function () {
        clearTimeout(hideTimeout);
    });

    // Hide the modal when leaving it
    document.getElementById('included-products-modal').addEventListener('mouseleave', function () {
        const modal = document.getElementById('included-products-modal');
        modal.style.display = 'none';
    });

    document.getElementById('amount-tendered').addEventListener('input', function () {
        const amountTenderedInput = parseFloat(this.value) || 0; // Get the input value or default to 0
        const totalPriceText = document.getElementById('total-price').textContent.replace('₱', '').replace(',', '');
        const totalPrice = parseFloat(totalPriceText) || 0; // Convert total price to a number

        const changeField = document.getElementById('change'); // Get the change field

        if (amountTenderedInput < totalPrice) {
            changeField.value = 'Insufficient amount'; // Show warning if tendered amount is less than total
        } else {
            const change = amountTenderedInput - totalPrice; // Calculate change
            // Format the change with commas
            changeField.value = `₱${change.toFixed(2).toLocaleString()}`;
        }
    });

    // Update the showReceiptModal function to display the cashier's name
    function showReceiptModal(orderDetails, amountTendered, cashierName, dateCreated, refNum, orNum) {
        const receiptModal = document.getElementById('receipt-modal');
        const receiptBody = receiptModal.querySelector('.item-table tbody');
    
        // Clear previous receipt content
        receiptBody.innerHTML = '';
    
        // Populate the receipt with order details
        orderDetails.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.name || 'Unknown Item'}</td>
                <td>${item.quantity}</td>
                <td>₱${(item.price * item.quantity).toFixed(2)}</td>
            `;
            receiptBody.appendChild(row);
        });
    
        // Update cashier name
        receiptModal.querySelector('.staff-details p:first-child').textContent = `Cashier: ${cashierName}`;
    
        // Update totals
        const totalAmount = orderDetails.reduce((total, item) => total + (item.price * item.quantity), 0);
        const change = amountTendered - totalAmount;
    
        receiptModal.querySelector('.totals p:nth-child(1) span').textContent = `₱${totalAmount.toFixed(2)}`;
        receiptModal.querySelector('.totals p:nth-child(2) span').textContent = `₱${amountTendered.toFixed(2)}`;
        receiptModal.querySelector('.totals p:nth-child(3) span').textContent = `₱${change.toFixed(2)}`;
    
        // Add date, invoice number, and official receipt number
        receiptModal.querySelector('.receipt').insertAdjacentHTML('afterbegin', `
            <div class="receipt-header">
                <p><strong>Date:</strong> ${new Date(dateCreated).toLocaleString()}</p>
                <p><strong>Invoice No:</strong> ${refNum}</p>
                <p><strong>Official Receipt No:</strong> ${orNum}</p>
            </div>
        `);
    
        // Show the receipt modal
        receiptModal.style.display = 'flex';  // Ensure modal shows with flexbox centering
    }
    
    // Close the receipt modal when the close button or cancel button is clicked ```javascript
    document.getElementById('close-receipt-modal').addEventListener('click', function () {
        document.getElementById('receipt-modal').style.display = 'none';
    });

    document.getElementById('cancelBtn').addEventListener('click', function () {
        document.getElementById('receipt-modal').style.display = 'none';
    });

    window.onclick = function(event) {
        const modal = document.getElementById('receipt-modal');
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };

    // Update the pay button functionality
    document.getElementById('pay-button').addEventListener('click', async function () {
        const rows = document.querySelectorAll('#order-list-body tr');

        if (rows.length === 0) {
            alert('You must select a product first.'); // Show alert if no products are selected
            return; // Exit the function to prevent further execution
        }

        const totalPriceText = document.getElementById('total-price').textContent.replace('₱', '').replace(',', '');
        const totalPrice = parseFloat(totalPriceText) || 0;
        const amountTendered2 = parseFloat(document.getElementById('amount-tendered').value) || 0;

        if (amountTendered2 < totalPrice) {
            alert('Insufficient amount tendered. Please provide a sufficient amount to complete the order.');
            return; // Exit the function if the amount tendered is insufficient
        }
        
        let productIds = [];
        let bundleIds = [];
        let totalAmount = 0;
        let totalQuantity = 0;
        let orderDetails = [];
        
        rows.forEach(row => {
            const productId = row.getAttribute('data-product-id');
            const quantityInput = row.querySelector('.quantity-input');
            const priceCell = row.querySelector('td:nth-child(3)');
            const price = parseFloat(priceCell.textContent.replace('₱', '').replace(',', ''));
            const quantity = parseInt(quantityInput.value);
            const itemName = row.querySelector('td:nth-child(2)').textContent; // Get the item name
        
            if (productId.startsWith('bundle-')) {
                bundleIds.push(productId.replace('bundle-', ''));
                orderDetails.push({
                    bundle_id: productId.replace('bundle-', ''),
                    quantity: quantity,
                    price: price,
                    name: itemName // Add the bundle name
                });
            } else if (productId.startsWith('product-')) {
                productIds.push(productId.replace('product-', ''));
                orderDetails.push({
                    product_id: productId.replace('product-', ''),
                    quantity: quantity,
                    price: price,
                    name: itemName // Add the product name
                });
            }
        
            totalAmount += price * quantity;
            totalQuantity += quantity;
        });
        
        const amountTendered = parseFloat(document.getElementById('amount-tendered').value) || 0;
        
        try {
            const response = await fetch('/orders', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    selectedProducts: productIds,
                    selectedBundles: bundleIds,
                    amountRendered: amountTendered,
                    price: totalAmount,
                    totalQuantity: totalQuantity,
                    orderDetails: orderDetails // Include order details with quantities
                })
            });
        
            if (response.ok) {
                const result = await response.json();
                alert(result.message); // Notify the user
                resetForm(); // Reset the form

                // Refresh products and bundles to reflect updated quantities
                await fetchProducts();
                await fetchBundles();

                // Use the cashierName returned from the server
                const cashierName = result.cashierName; // Get the cashier's name from the response
                showReceiptModal(orderDetails, amountTendered, cashierName, result.dateCreated, result.refNum, result.orNum);
            } else {
                const error = await response.json();
                alert(`Error: ${error.error}`);
            }
        } catch (error) {
            console.error("Error processing order:", error);
            alert("An error occurred while processing your order.");
        }
    });

    // Print button click event
    document.getElementById("printBtn").addEventListener("click", function () {
        // Select only the receipt content excluding the buttons
        var content = document.querySelector(".receipt").innerHTML; // Select only the receipt content
        var printWindow = window.open("", "", "height=500, width=800");
        
        printWindow.document.write('<html><head><title>Receipt</title>');
        printWindow.document.write('<style>'); // Optional: Add some styles for printing
        printWindow.document.write('body { font-family: Arial, sans-serif; }');
        printWindow.document.write('.receipt { margin: 20px; }');
        printWindow.document.write('</style>');
        printWindow.document.write('</head><body>');
        printWindow.document.write(content);
        printWindow.document.write('</body></html>');
        
        printWindow.document.close(); // Close the document to finish writing
        printWindow.print(); // Trigger the print dialog
    });

    function resetForm() {
        // Clear the order list
        document.getElementById('order-list-body').innerHTML = '';

        // Reset the total price, amount tendered, and change fields
        document.getElementById('total-price').textContent = '₱0.00'; // Reset the total price display
        document.getElementById('amount-tendered').value = ''; // Clear amount tendered input
        document.getElementById('change').value = ''; // Clear change field

        // Reset the search input
        document.getElementById('product-search').value = ''; // Reset product search input
        // Optionally clear the category selection
        $('#category-select').val(null).trigger('change'); // Reset category select2 dropdown
    }

    // Add an event listener for the cancel button
    document.querySelector('#cancel_daw').addEventListener('click', function () {
        resetForm(); // Reset the form without affecting the product and bundle display
    });
}); 