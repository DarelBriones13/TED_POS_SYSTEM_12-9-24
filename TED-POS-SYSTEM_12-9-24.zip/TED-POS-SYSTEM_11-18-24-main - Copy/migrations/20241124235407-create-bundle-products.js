// migrations/xxxx-create-bundle-products.js
'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('BundleProducts', {
      bundle_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'Bundles',
          key: 'bundle_id'
        },
        onDelete: 'CASCADE',
        allowNull: false
      },
      product_id: {
        type: Sequelize.INTEGER,
        references: {
          model: 'products',
          key: 'product_id'
        },
        onDelete: 'CASCADE',
        allowNull: false
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('BundleProducts');
  }
};