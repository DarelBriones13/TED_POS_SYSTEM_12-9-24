'use strict';
const {
  Model
} = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class products extends Model {
    static associate(models) {
      // Define associations
      products.belongsToMany(models.Bundles, {
        through: 'BundleProducts', // Join table
        foreignKey: 'product_id',
        otherKey: 'bundle_id'
      });
      products.belongsTo(models.Category, { foreignKey: 'category_id', as: 'category' });
    }
  }

  products.init({
    product_id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    product_name: {
      type: DataTypes.STRING
    },
    product_model: {
      type: DataTypes.STRING
    },
    product_img: {
      type: DataTypes.STRING
    },
    product_quantity: {
      type: DataTypes.INTEGER
    },
    selling_price: {
      type: DataTypes.DECIMAL
    },
    category_id: {
      type: DataTypes.INTEGER
    },
    product_status: { // Existing attribute
      type: DataTypes.STRING,
      allowNull: true
    }
  }, {
    sequelize,
    modelName: 'products',
  });

  return products;
};
