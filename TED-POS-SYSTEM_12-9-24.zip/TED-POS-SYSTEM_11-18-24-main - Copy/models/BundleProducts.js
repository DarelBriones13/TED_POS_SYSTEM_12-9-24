// models/BundleProducts.js
'use strict';
module.exports = (sequelize, DataTypes) => {
  const BundleProducts = sequelize.define('BundleProducts', {
    bundle_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'Bundles', // Name of the Bundles table
        key: 'bundle_id'
      }
    },
    product_id: {
      type: DataTypes.INTEGER,
      references: {
        model: 'products', // Name of the Products table
        key: 'product_id'
      }
    }
  }, {
    tableName: 'BundleProducts' // Ensure this matches the actual table name
  });

  BundleProducts.associate = function(models) {
    // Define associations if needed
    BundleProducts.belongsTo(models.Bundles, { foreignKey: 'bundle_id' });
    BundleProducts.belongsTo(models.products, { foreignKey: 'product_id' });
  };

  return BundleProducts;
};